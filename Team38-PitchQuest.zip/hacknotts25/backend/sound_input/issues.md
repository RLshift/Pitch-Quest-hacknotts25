## ISSUES FACED ALONG THE JORUNEY

- Too much background noise picked up - being fixed with Noise Cancellation.
- Noise cancellation too high - needs tuned.

- It all broke.
